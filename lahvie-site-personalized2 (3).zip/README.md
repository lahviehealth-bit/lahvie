Run: npm install && npm run dev
Open http://localhost:3000
